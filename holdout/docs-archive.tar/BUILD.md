# Building ziptastic

Written 2026-11-04. The recipe that actually works, because until now it lived only in a session
log and cost many hours to reconstruct.

## Markers

`TODO(name-date): what and why` is the convention. Not `FIXME`, not bare `TODO` — the tag says who
left it and when, and `grep -rn "TODO(" src include` is the whole backlog.

There were zero markers in 12,460 lines before 2026-11-08, and the audit that day produced three
things a marker would have made findable: two container encoders that treated a short encode as
failure only implicitly, and six `catch (...)` blocks that swallow everything without counting it.
The first two are fixed; the third is marked.

## What you need

- **CMake ≥ 3.25**, **Ninja**, and a **C++20** compiler.
- No system packages beyond that: brotli, brunsli, libbsc, zpaq, ppmd, preflate and liblzma are
  vendored under `vendor/`.
- **~2 GB of RAM**; that is what every number in `FINDINGS.md` was measured on. It also reports two
  cores and delivers **one core of throughput** — two threads take as long as two sequential runs —
  so no thread claim in this repository has been tested. `FINDINGS.md` §0 has the measurement. If you
  are timing anything about `--parallel` or `-T`, check your own machine first.

## The normal path

```bash
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
ctest --test-dir build          # 37 suites, ~4 minutes
./build/ziptastic version
```

That is the whole of it on a machine with a working toolchain and enough RAM to compile brunsli and
brotli at once.

## When there is no compiler at all

A container with no `g++`, no `cmake` and no `ninja`, and no root to install them, still builds
this: pip ships all three as wheels, including a complete C/C++ toolchain.

```bash
pip install --user ziglang cmake ninja
ZIG=$(python3 -c 'import ziglang,os;print(os.path.dirname(ziglang.__file__))')/zig
printf '#!/bin/sh\nexec %s cc  -target x86_64-linux-gnu "$@"\n' "$ZIG" > ~/.local/bin/zigcc
printf '#!/bin/sh\nexec %s c++ -target x86_64-linux-gnu "$@"\n' "$ZIG" > ~/.local/bin/zigcxx
chmod +x ~/.local/bin/zigcc ~/.local/bin/zigcxx

cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release \
      -DCMAKE_C_COMPILER=$HOME/.local/bin/zigcc \
      -DCMAKE_CXX_COMPILER=$HOME/.local/bin/zigcxx
```

Two things to know. The configure step alone takes **~5 minutes** here, because CMake compiles and
runs its feature probes one at a time through a wrapper that is slower than a native compiler.
And this is the toolchain the depfile note below is about: with zig wrappers, strip the depfiles
before the first build, and touch `src/` and `tests/` after any header change.

Building every target in one `cmake --build build -j3` on two cores will exceed a five-minute
command limit; the target-by-target loop below is the way through, and it resumes where it stopped.

## If the build is slow, runs out of memory, or the compiler is odd

Two things this project actually hit, and what to do about them.

### 1. Build the vendors one at a time

A single `cmake --build build -j3` on 2 cores can exceed a 5-minute command limit and lose its
place. Building target by target resumes cleanly:

```bash
for t in brotli_vendor brunsli_vendor bsc_vendor zpaq_vendor ppmd_vendor \
         liblzma preflate_vendor preflate_shim chce_core ziptastic; do
  cmake --build build -j3 --target "$t" || break
done
```

### 2. If you use a zig-based toolchain, strip depfiles before building

With `CMAKE_C_COMPILER`/`CXX_COMPILER` pointed at zig wrappers, ninja's dependency log can be
written in a form it then refuses to parse, and the build stops with a corrupt-log error. Removing
the depfile declarations from the generated rules fixes it:

```bash
python3 - <<'PY'
import re
p = 'build/CMakeFiles/rules.ninja'
s = open(p).read()
s = re.sub(r'^  deps = gcc\n', '', s, flags=re.M)
s = re.sub(r'^  depfile = .*\n', '', s, flags=re.M)
open(p, 'w').write(s)
PY
rm -f build/.ninja_deps build/.ninja_log
```

**The cost of that fix is real**: with depfiles stripped, a change to a *header* does not trigger a
rebuild of the sources that include it. That includes `src/engine/compressor.hpp`, which is where the
stats struct lives — editing it and rebuilding only the touched file leaves every other object
compiled against the old layout, and the first symptom is not a link error but a corrupted argument:
a `CompressOptions` with a block size of zero, returned as `bad-block-size` from a call that passed
it correctly. It cost a debugging session on 2026-11-04. After any edit under `include/` **or to a
`.hpp` under `src/`**, do:

```bash
find src tests -name '*.cpp' -exec touch {} +
cmake --build build -j3
```

A stale binary built against an old header has cost this project three separate debugging
sessions, twice presenting as a logic bug in code that was correct.

## Cross-compiling

Nothing in the tree is platform-specific except the thread pool and the CPUID dispatch in
`sha256.cpp`. Windows and Linux are what has been built; macOS has not been tried and is not
supported.

## What "it works" looks like

```
$ ./build/ziptastic version
ziptastic 1.4.2 (CHCE format v8)

$ head -c 200000 /dev/urandom > t.bin
$ ./build/ziptastic c -9 t.bin            # writes t.bin.dr
$ ./build/ziptastic d t.bin.dr            # writes t.bin, byte-identical
```

If `ctest` is green and that round trip is byte-exact, you have a working build.

The published asset is built on `ubuntu-22.04` in the release workflow, which gives it a
**glibc 2.34** floor — Debian 12, Ubuntu 22.04 and RHEL 9 all run it. Building locally
produces a binary with your own toolchain's floor, which is usually newer and is why a
locally-built binary can fail on an older machine that the release works on. See the
glibc gate in `.github/workflows/release.yml`.

### Why the floor is 2.34 and not 2.17

1.4.1 was hand-built against glibc 2.17 (CentOS 7). 2.34 covers Debian 12, Ubuntu 22.04,
Ubuntu 24.04 and RHEL 9 — every distribution anyone is currently installing. Going back to
2.17 means cross-compiling, and the only toolchain that does it here is `zig`:

```
$ pip install ziglang
$ cmake -DCMAKE_C_COMPILER=.../zig-cc-2.17 -DCMAKE_CXX_COMPILER=.../zig-cxx-2.17
-- The C compiler identification is Clang 22.1.8
-- Configuring done (108.6s)      # compiler feature tests, once
```

It works, and it is expensive: the vendored tree is compiled from scratch by a second
toolchain (327 targets, roughly four times the GCC build's wall time), so a release becomes
a twenty-minute job that depends on a Python package that ships its own compiler. That is a
dependency the project does not otherwise have.

**Decision:** 2.34 is the floor. What would change it: a user on CentOS 7 or Ubuntu 20.04
who cannot upgrade. If that happens, the recipe above is the one to follow, and the glibc
gate in `release.yml` will hold the new floor to whatever the build actually produces.

The offset table has its own smoke test, and it is the one to run after touching the trailer:

```
$ ./build/ziptastic info t.bin.dr
...
blocks         1
block table    verified against the manifest digest, 108 bytes read of 118284
```

`verified` is doing work: `info` reads every block header at the position the table names and
re-hashes them into the manifest before printing anything.

**The release binary's floor.** A release is built on `ubuntu-22.04` with
`-static-libstdc++ -static-libgcc`, so the published asset needs **glibc 2.35** —
Debian 12, Ubuntu 22.04 and later. Building on
`ubuntu-latest` instead produces a binary that requires glibc 2.38 and libstdc++
`GLIBCXX_3.4.32`, which excludes Debian 12, Ubuntu 22.04 and every RHEL 9; v1.4.2 was
published that way before this was noticed. The release workflow now reads the floor back
out of the finished binary with `objdump` and refuses to publish above 2.35. Container
builds (debian:bullseye, glibc 2.31) were tried and abandoned: bullseye's apt repositories
have moved to the archive, so the image can no longer install git, and without git there
are no submodules.

