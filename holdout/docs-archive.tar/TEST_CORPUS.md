> **Superseded for current figures by [`FINDINGS.md`](FINDINGS.md).** This document is the
> working record — how the number was arrived at and what was corrected along the way. Where the
> two disagree, `FINDINGS.md` is right.

# The real-world corpus, and what it measured

Written 2026-11-02. Five real images were supplied for testing. This records what each
one actually is, what the engine does with it, and which of them is useful for which
piece of work — including one assumption they disprove.

## What the files are

| file | size | what it actually is |
|---|---|---|
| `TinyIsoTest.iso` | 4,980,736 | cooked ISO9660 — 2,432 sectors of 2,048 bytes |
| `kolibrios … .iso` | 103,766,016 | cooked ISO9660 — 50,667 sectors of 2,048 bytes |
| `kolibrios … .img` | 1,474,560 | 1.44 MB floppy image (FAT12), 2,880 sectors of 512 bytes |
| `kolibrios … .distr.zip` | 53,063,864 | a ZIP of the distribution |
| `kolibrios … .raw` | 134,217,728 | **a raw disk image, not a raw CD image** |

The `.raw` was expected to be the ECM test material. It is not: 134,217,728 =
65,536 × 2,048, and it starts with `33 C0 8E D0 BC 00 7C …` — a boot sector, i.e. x86
code — not the `00 FF×10 00` sync pattern of a 2,352-byte CD sector. **ECM still has no
test material**: it needs a raw Mode-1 CD image, which none of these are.

## Measured, `-9`, round-trip verified

Re-measured on 2026-11-02 after ECM, PNG and BMP landed — identical to the first run, so
none of the new stages disturbed a file they do not apply to.

| file | size | compressed | gain | time | `layers`/`layers2` |
|---|---|---|---|---|---|
| `TinyIsoTest.iso` | 4,980,736 | **3,333,900** | **−33.1%** | 36 s | 0x00 / 0x00 |
| `kolibrios … .img` | 1,474,560 | **1,257,827** | **−14.7%** | 8 s | 0x00 / 0x00 |

Both round-trip byte-exact. Neither fires a Layer 0 transform — a cooked ISO and a FAT12
floppy have no DEFLATE, no base64, no PCM, no PNG, no BMP and no CD sectors in them, so
the backend does all the work. That is the correct answer, not a missing feature.

The timings are worth recording: **~0.14 MB/s on this box at `-9`**. That is the number
that decides what can be measured in a single 300 s call — anything over about 40 MB is
out of reach, which is why the 53 MB ZIP and the 99 MB and 128 MB images remain
unmeasured.

## What did not finish, and why

**A slice is not a substitute, and that is worth knowing.** Taking the first 8 MB of the
ZIP and compressing it gives 7,933,212 bytes with precomp **on or off, identically** —
`layers 0x00/0x00`. That is not precomp failing; a slice cuts through members, so the
DEFLATE streams it finds are truncated and no member can be inflated. A container
transform can only be measured on whole members, which means the whole file, which means
more than one call can give.

`… .distr.zip` (53 MB) did not complete in a 260 s run at default settings. On this box
the engine runs at roughly 0.3–0.6 MB/s, so a 53 MB archive needs several minutes before
precomp has even finished inflating it. The 99 MB ISO and the 128 MB raw image are out of
reach for a single 300 s call for the same reason.

**This is a sandbox constraint, not an engine defect**, but it is worth stating plainly:
every large-file number in this repository was measured on fixtures of a few MB, and the
corpus above has not been measured end to end. A machine with more time per call — or a
`bench` mode that reports after each block — is what that needs.

## What these files are good for

- **`TinyIsoTest.iso` and the `.img`** are honest end-to-end round-trip tests on real
  binary images, which the synthetic fixtures are not. They belong in a corpus test.
- **The `.distr.zip`** is the best available test of the ZIP path on a real archive —
  dozens of members, real DEFLATE, mixed content — and it is the one worth running on a
  machine that can give it ten minutes.
- **The two ISOs** would exercise the precomp scanner at scale.
- **None of them can validate ECM.** For that we need a `.bin`/`.raw` ripped from a CD
  with 2,352-byte sectors; `cdrdao`, `dd` on a CD device, or any game-repack source would
  provide one.

## Status

Corpus recorded. Two files measured, three unmeasured for time. ECM remains blocked on
test material rather than on code.

## The 53 MB ZIP, finally measured — and precomp declines on it

Ran with `--parallel` (two threads, 256 KiB blocks) so it fits in a call: **4 min 8 s**,
53,063,864 → **52,759,584** (−0.57%), round trip byte-exact.

Header of the result: `flags = 0x01` (coarse index only), `layers = 0x10` (base64),
`layers2 = 0x00`.

**Precomp did not fire.** That is the notable part. The archive has 1,172 members — 796
deflated, 376 stored — so there is real DEFLATE in it, and `-9` sets `precomp = true`. It
was tried and declined. Re-run at `-b 8192` (8 MiB blocks, so members cannot be cut by a
block boundary) gave the identical 52,759,584 bytes, so block size is not the reason.

The likely reason is the gate, and it is the right behaviour rather than a bug:
`precomp_helps` keeps the inflated payload only if it compresses smaller than the original
DEFLATE stream, and this archive is thousands of **small** members (≈45 KB average). A
deflate stream that small is already near what the backend can do with the same bytes, and
the per-member framing is not free. So precomp pays on a few large members and not on many
small ones — which is exactly the field impression recorded in `REPACK_PIPELINES.md`
("precomp is often useless and slow on intense mode but worth it on games").

What did fire was **base64** (`layers = 0x10`). It was investigated rather than left as a
suspicion, because a base64 run being accepted inside a ZIP is the kind of thing that
should be a bug:

| run on the full archive | bytes |
|---|---|
| `-9 --parallel --no-base64` | 52,759,638 |
| `-9 --parallel` (base64 allowed) | **52,759,584** |

**54 bytes.** The gate's sample said the run would pay, and it did — by 54 bytes out of
52.7 MB. So it is not a bug, it is a marginal decision correctly made; the gate cannot
know that a 256 KiB sample's small win will not grow on the whole file.

On an 8 MB slice of the same archive base64 does not fire at all (`layers 0x00`) and the
output is byte-identical with and without it — the sample there showed no run worth taking.
Same file class, two different decisions, both defensible.

## Still unmeasured

The 99 MB ISO and the 128 MB raw image. At ~0.14 MB/s single-threaded and ~0.21 MB/s with
`--parallel`, they need 8 and 10 minutes. Everything else in the corpus is now measured.
